IMS SALES & INVENTORY — MOBILE HTML APP

1. Extract the ZIP file.
2. Open index.html in Chrome, Edge or another modern browser.
3. The app saves records in that browser using local storage.
4. For installable/offline PWA behavior, upload the extracted folder to any HTTPS web host and use “Add to Home Screen”.
5. Open Reports to download all reports in one Excel file or download each report separately.
6. Open Settings to create a Full Backup or separate JSON backups for each module.
7. Before restoring, select the matching backup type and then choose the JSON file.
8. Restoring replaces the selected module, so keep a current Full Backup first. Clearing browser/site data removes locally saved records.

Included: Dashboard, invoices, retailers, vendors, multi-item purchases, inventory, returns, targets, Excel reports, P&L, full/module backup and restore, company settings, edit history, 58mm invoice printing and automatic IDs.
